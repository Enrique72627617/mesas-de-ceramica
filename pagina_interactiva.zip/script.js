document.getElementById('action-button').addEventListener('click', function() {
  window.location.href = '#products';
});

document.getElementById('contact-form').addEventListener('submit', function(event) {
  event.preventDefault();
  alert('¡Gracias por contactarnos! Te responderemos pronto.');
  this.reset();
});